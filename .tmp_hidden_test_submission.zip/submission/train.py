from __future__ import annotations

import tempfile
from pathlib import Path

from scorer import score_split
from sdk.api import ensure_dir, load_json, write_json
from sdk.simplefold import (
    can_use_cached_bundle_features,
    run_simplefold_batch_inference,
    run_simplefold_cached_bundle_inference,
)


def manifest_samples(split_dir: Path) -> list[dict]:
    manifest_path = split_dir / "manifest.json"
    if not manifest_path.exists():
        return []
    return load_json(manifest_path).get("samples", [])


def run_split_inference(
    *,
    split_dir: Path,
    output_dir: Path,
    config: dict,
) -> None:
    ensure_dir(output_dir / "predictions")
    samples = manifest_samples(split_dir)
    target_ids = [sample["target_id"] for sample in samples]
    fasta_root = split_dir / "fastas"

    if can_use_cached_bundle_features(samples):
        run_simplefold_cached_bundle_inference(
            split_dir=split_dir,
            samples=samples,
            output_dir=output_dir,
            config=config,
        )
        return

    if not fasta_root.exists():
        raise RuntimeError(f"bundle split is missing fastas: {split_dir}")

    run_simplefold_batch_inference(
        fasta_root=fasta_root,
        target_ids=target_ids,
        output_dir=output_dir,
        config=config,
    )


def candidate_configs(base_config: dict) -> list[dict]:
    base_steps = int(base_config.get("num_steps", 25))
    base_tau = float(base_config.get("tau", 0.01))
    candidates = []
    seen: set[tuple[int, float]] = set()
    for steps, tau in (
        (base_steps, base_tau),
        (max(5, min(15, base_steps)), base_tau),
        (min(50, max(base_steps, 35)), base_tau),
        (base_steps, 0.02),
    ):
        key = (int(steps), float(tau))
        if key in seen:
            continue
        seen.add(key)
        candidate = dict(base_config)
        candidate["num_steps"] = int(steps)
        candidate["tau"] = float(tau)
        candidates.append(candidate)
    return candidates


def summary_score(scoring: dict) -> float:
    summary = scoring.get("summary") or {}
    tm_score = summary.get("mean_tm_score")
    if tm_score is None:
        return float("-inf")
    return float(tm_score)


def select_best_config(context, base_config: dict) -> tuple[dict, dict]:
    val_manifest_path = context.bundle.val_dir / "manifest.json"
    val_samples = manifest_samples(context.bundle.val_dir)
    if not val_manifest_path.exists() or not val_samples:
        print("[submission] no val split available; using provided config directly", flush=True)
        return dict(base_config), {"mode": "no_val_split", "trials": []}

    best_config: dict | None = None
    best_scoring: dict | None = None
    trials: list[dict] = []

    for index, candidate in enumerate(candidate_configs(base_config), 1):
        with tempfile.TemporaryDirectory(prefix="submission_val_search_") as tmp_dir:
            candidate_output_dir = Path(tmp_dir)
            print(
                f"[submission] validating candidate [{index}] model={candidate.get('simplefold_model')} "
                f"steps={candidate.get('num_steps')} tau={candidate.get('tau')}",
                flush=True,
            )
            run_split_inference(
                split_dir=context.bundle.val_dir,
                output_dir=candidate_output_dir,
                config=candidate,
            )
            scoring = score_split(
                val_manifest_path,
                candidate_output_dir / "predictions",
            )
            trial = {
                "num_steps": candidate.get("num_steps"),
                "tau": candidate.get("tau"),
                "valid": scoring.get("valid"),
                "mean_tm_score": (scoring.get("summary") or {}).get("mean_tm_score"),
                "mean_lddt": (scoring.get("summary") or {}).get("mean_lddt"),
                "num_invalid_targets": (scoring.get("summary") or {}).get("num_invalid_targets"),
            }
            trials.append(trial)
            print(
                f"[submission] candidate [{index}] tm_score={trial['mean_tm_score']} "
                f"lddt={trial['mean_lddt']} invalid_targets={trial['num_invalid_targets']}",
                flush=True,
            )
            if best_scoring is None or summary_score(scoring) > summary_score(best_scoring):
                best_config = dict(candidate)
                best_scoring = scoring

    assert best_config is not None
    search_report = {
        "mode": "val_model_selection",
        "selected": {
            "num_steps": best_config.get("num_steps"),
            "tau": best_config.get("tau"),
            "simplefold_model": best_config.get("simplefold_model"),
        },
        "best_summary": (best_scoring or {}).get("summary"),
        "trials": trials,
    }
    write_json(context.output_dir / "search_results.json", search_report)
    print(
        f"[submission] selected config model={best_config.get('simplefold_model')} "
        f"steps={best_config.get('num_steps')} tau={best_config.get('tau')}",
        flush=True,
    )
    return best_config, search_report


def main(context, config) -> None:
    ensure_dir(context.output_dir / "predictions")
    best_config, _search_report = select_best_config(context, dict(config))

    print("[submission] running test split with selected config", flush=True)
    run_split_inference(
        split_dir=context.bundle.test_dir,
        output_dir=context.output_dir,
        config=best_config,
    )
